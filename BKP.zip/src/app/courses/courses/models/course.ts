export interface Course {
  _id: number;
  name:string;
  category: string;
}
